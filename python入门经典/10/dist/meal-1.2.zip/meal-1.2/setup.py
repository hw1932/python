from distutils.core import setup
setup(name='meal',version='1.2',py_modules='meal')